package com.moviepass.wallet

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID

class MainActivity : Activity() {
    private val bg = Color.rgb(9, 10, 16)
    private val panel = Color.rgb(22, 24, 35)
    private val muted = Color.rgb(151, 154, 173)
    private val accent = Color.rgb(185, 155, 255)
    private val prefs by lazy { getSharedPreferences("moviepass", MODE_PRIVATE) }
    private lateinit var root: LinearLayout
    private var filter = "Upcoming"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        handleIncoming(intent)
        showHome()
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleIncoming(intent)
        showHome()
    }

    private fun handleIncoming(i: Intent?) {
        if (i == null) return
        val action = i.action ?: return
        if (action == Intent.ACTION_SEND || action == Intent.ACTION_VIEW) {
            val uri = if (action == Intent.ACTION_SEND) i.getParcelableExtra<Uri>(Intent.EXTRA_STREAM) else i.data
            val text = i.getStringExtra(Intent.EXTRA_TEXT).orEmpty()
            if (uri != null) importUri(uri, text) else if (text.isNotBlank()) importText(text)
        }
    }

    private fun showHome() {
        root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(bg); setPadding(dp(20), dp(18), dp(20), dp(12)) }
        val scroll = ScrollView(this)
        val content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        scroll.addView(content)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        content.addView(row {
            addView(label("MOVIEPASS", 13, accent, true), LinearLayout.LayoutParams(0, -2, 1f))
            addView(label("WALLET  ✦", 12, muted, true))
        })
        content.addView(space(22))
        content.addView(label("Your cinema,\nin one place.", 31, Color.WHITE, true))
        content.addView(space(8))
        content.addView(label("Every ticket. Every show. Zero searching.", 13, muted))
        content.addView(space(22))
        val tickets = loadTickets()
        val upcoming = tickets.filter { it.optString("status") != "Used" && it.optString("status") != "Expired" }
        val stats = row {
            addView(statCard("${upcoming.size}", "UPCOMING"), LinearLayout.LayoutParams(0, dp(76), 1f))
            addView(spaceH(10))
            addView(statCard("${tickets.size - upcoming.size}", "PAST SHOWS"), LinearLayout.LayoutParams(0, dp(76), 1f))
        }
        content.addView(stats)
        content.addView(space(22))
        content.addView(row {
            addView(label("MY TICKETS", 16, Color.WHITE, true), LinearLayout.LayoutParams(0, -2, 1f))
            addView(label("${tickets.size} SAVED", 10, muted, true))
        })
        content.addView(space(12))
        content.addView(row {
            listOf("Upcoming", "Used", "All").forEach { f ->
                val b = TextView(this@MainActivity).apply {
                    text = f; textSize = 12f; setTextColor(if (filter == f) bg else muted); gravity = Gravity.CENTER
                    background = shape(if (filter == f) accent else panel, 18)
                    setPadding(dp(16), dp(9), dp(16), dp(9)); setOnClickListener { filter = f; showHome() }
                }
                addView(b); addView(spaceH(7))
            }
        })
        content.addView(space(12))
        val shown = when (filter) {
            "Upcoming" -> tickets.filter { it.optString("status") != "Used" && it.optString("status") != "Expired" }
            "Used" -> tickets.filter { it.optString("status") == "Used" || it.optString("status") == "Expired" }
            else -> tickets
        }
        if (shown.isEmpty()) {
            val empty = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER; background = shape(panel, 22); setPadding(dp(20), dp(28), dp(20), dp(28)) }
            empty.addView(label("🎟", 34, Color.WHITE, true)); empty.addView(space(8))
            empty.addView(label("Your next movie starts here", 17, Color.WHITE, true)); empty.addView(space(5))
            empty.addView(label("Share a ticket from PVR, BookMyShow,\nDistrict or INOX to add it instantly.", 12, muted))
            content.addView(empty)
        } else shown.forEach { content.addView(ticketCard(it)); content.addView(space(12)) }
        content.addView(space(12))
        content.addView(label("QUICK IMPORT", 11, muted, true)); content.addView(space(9))
        content.addView(actionButton("＋   Import ticket / PDF / image") { pickFile() })
        content.addView(space(10))
        content.addView(actionButton("✉   Connect Gmail for ticket emails") { gmailInfo() })
        content.addView(space(20))
        content.addView(label("SUPPORTED SOURCES", 10, muted, true)); content.addView(space(8))
        content.addView(label("PVR  •  BOOKMYSHOW  •  DISTRICT  •  INOX", 11, Color.WHITE, true))
        content.addView(space(24))
        content.addView(label("Private by design · Tickets stay on this device", 10, muted))
        setContentView(root)
    }

    private fun ticketCard(t: JSONObject): View {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; background = shape(panel, 20); setPadding(dp(16), dp(15), dp(16), dp(15)) }
        box.addView(row {
            addView(label(t.optString("source", "MOVIE TICKET").uppercase(), 10, accent, true), LinearLayout.LayoutParams(0, -2, 1f))
            addView(label(t.optString("status", "Upcoming").uppercase(), 9, muted, true))
        })
        box.addView(space(12))
        box.addView(label(t.optString("movie", "Movie ticket"), 20, Color.WHITE, true))
        box.addView(space(8))
        box.addView(label(listOf(t.optString("date"), t.optString("time"), t.optString("theatre")).filter { it.isNotBlank() }.joinToString("  •  ").ifBlank { "Details pending — tap to review" }, 12, muted))
        box.addView(space(12))
        box.addView(row {
            addView(label("SEATS  ${t.optString("seats", "—")}", 11, Color.WHITE, true), LinearLayout.LayoutParams(0, -2, 1f))
            addView(label("VIEW TICKET  ↗", 10, accent, true))
        })
        box.setOnClickListener { showTicket(t) }
        return box
    }

    private fun showTicket(t: JSONObject) {
        val body = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(22), dp(18), dp(22), dp(10)) }
        body.addView(label(t.optString("movie", "Movie ticket"), 23, Color.WHITE, true)); body.addView(space(12))
        listOf("Platform" to t.optString("source"), "Theatre" to t.optString("theatre"), "Date" to t.optString("date"), "Time" to t.optString("time"), "Seats" to t.optString("seats"), "Booking ID" to t.optString("bookingId"), "Ticket code" to t.optString("code")).forEach {
            if (it.second.isNotBlank()) { body.addView(label(it.first.uppercase(), 9, muted, true)); body.addView(label(it.second, 14, Color.WHITE)); body.addView(space(9)) }
        }
        body.addView(label("QR / barcode", 10, muted, true)); body.addView(space(7))
        val attachment = t.optString("attachment")
        if (attachment.isNotBlank() && File(attachment).exists() && attachment.endsWith(".jpg", true) || attachment.endsWith(".png", true)) {
            val iv = ImageView(this).apply { setImageURI(Uri.fromFile(File(attachment))); adjustViewBounds = true }
            body.addView(iv)
        } else {
            val code = TextView(this).apply { text = t.optString("code", t.optString("bookingId", "Ticket saved")); textSize = 16f; typeface = Typeface.MONOSPACE; gravity = Gravity.CENTER; setTextColor(Color.WHITE); background = shape(Color.rgb(40, 42, 56), 12); setPadding(dp(16), dp(24), dp(16), dp(24)) }
            body.addView(code)
        }
        AlertDialog.Builder(this).setView(body).setPositiveButton("Mark used") { _, _ -> t.put("status", "Used"); updateTicket(t); showHome() }.setNegativeButton("Close", null).show()
    }

    private fun importText(raw: String) {
        val s = raw.replace("\r", " ").replace("\n", " ")
        val source = when { s.contains("pvr", true) -> "PVR"; s.contains("bookmyshow", true) || s.contains("bms", true) -> "BookMyShow"; s.contains("district", true) -> "District"; s.contains("inox", true) -> "INOX"; else -> "Imported" }
        val movie = find(s, "(?i)(?:movie|film)\\s*[:\\-]?\\s*([A-Z0-9][A-Za-z0-9 &'():.-]{2,55})") ?: "Movie ticket"
        val date = find(s, "(?i)(\\d{1,2}[/-][A-Za-z0-9/-]+\\d{2,4}|\\d{1,2}\\s+[A-Za-z]{3,9}\\s+\\d{4})") ?: ""
        val time = find(s, "(?i)(\\d{1,2}:\\d{2}\\s?(?:AM|PM)?)") ?: ""
        val seats = find(s, "(?i)(?:seat|seats)\\s*[:#-]?\\s*([A-Z0-9, /-]{1,30})") ?: ""
        val booking = find(s, "(?i)(?:booking|booking id|order id|confirmation)\\s*(?:id)?\\s*[:#-]?\\s*([A-Z0-9-]{5,25})") ?: ""
        val t = JSONObject().put("id", UUID.randomUUID().toString()).put("source", source).put("movie", movie.trim()).put("date", date).put("time", time).put("seats", seats.trim()).put("bookingId", booking).put("code", booking).put("status", "Upcoming").put("created", System.currentTimeMillis())
        saveTicket(t)
        AlertDialog.Builder(this).setTitle("Ticket imported").setMessage("We added the shared content to your wallet. Check the details and edit anything that wasn't detected correctly.\n\nSource: $source\nMovie: ${movie.trim()}").setPositiveButton("View wallet", null).show()
    }

    private fun importUri(uri: Uri, sharedText: String) {
        try {
            val ext = when {
                contentResolver.getType(uri)?.contains("pdf") == true -> ".pdf"
                contentResolver.getType(uri)?.startsWith("image/") == true -> ".jpg"
                else -> ".dat"
            }
            val file = File(filesDir, "ticket_${System.currentTimeMillis()}$ext")
            contentResolver.openInputStream(uri)?.use { input -> file.outputStream().use { input.copyTo(it) } }
            val t = JSONObject().put("id", UUID.randomUUID().toString()).put("source", detectSource(sharedText)).put("movie", "Imported ticket — review details").put("date", "").put("time", "").put("seats", "").put("bookingId", "").put("code", "").put("status", "Upcoming").put("attachment", file.absolutePath).put("created", System.currentTimeMillis())
            saveTicket(t)
            Toast.makeText(this, "Ticket file saved. Add or verify the show details.", Toast.LENGTH_LONG).show()
        } catch (e: Exception) { Toast.makeText(this, "Couldn't import this file: ${e.message}", Toast.LENGTH_LONG).show() }
    }

    private fun detectSource(s: String) = when { s.contains("pvr", true) -> "PVR"; s.contains("bookmyshow", true) -> "BookMyShow"; s.contains("district", true) -> "District"; s.contains("inox", true) -> "INOX"; else -> "Imported" }
    private fun find(s: String, regex: String): String? = Regex(regex).find(s)?.groupValues?.getOrNull(1)?.trim()
    private fun loadTickets(): List<JSONObject> { val a = try { JSONArray(prefs.getString("tickets", "[]")) } catch (_: Exception) { JSONArray() }; return (0 until a.length()).mapNotNull { a.optJSONObject(it) }.sortedByDescending { it.optLong("created") } }
    private fun saveTicket(t: JSONObject) { val a = JSONArray(); loadTickets().forEach { a.put(it) }; a.put(t); prefs.edit().putString("tickets", a.toString()).apply() }
    private fun updateTicket(t: JSONObject) { val a = JSONArray(); loadTickets().forEach { a.put(if (it.optString("id") == t.optString("id")) t else it) }; prefs.edit().putString("tickets", a.toString()).apply() }

    private fun pickFile() { val i = Intent(Intent.ACTION_OPEN_DOCUMENT).apply { addCategory(Intent.CATEGORY_OPENABLE); type = "*/*"; putExtra(Intent.EXTRA_MIME_TYPES, arrayOf("application/pdf", "image/*", "text/plain")) }; startActivityForResult(i, 42) }
    @Deprecated("Legacy callback for broad Android compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) { super.onActivityResult(requestCode, resultCode, data); if (requestCode == 42 && resultCode == RESULT_OK) data?.data?.let { importUri(it, "") ; showHome() } }
    private fun gmailInfo() { AlertDialog.Builder(this).setTitle("Gmail import").setMessage("Gmail auto-import needs Google OAuth consent and a configured Gmail API project. This build includes the import entry point, but live inbox sync is not enabled yet. For now, open the ticket email and use Share → MoviePass Wallet, or share its PDF attachment.").setPositiveButton("Got it", null).show() }

    private fun actionButton(text: String, click: () -> Unit) = TextView(this).apply { this.text = text; textSize = 14f; typeface = Typeface.DEFAULT_BOLD; setTextColor(Color.WHITE); gravity = Gravity.CENTER; background = shape(Color.rgb(48, 40, 70), 15); setPadding(dp(16), dp(15), dp(16), dp(15)); setOnClickListener { click() } }
    private fun statCard(value: String, caption: String) = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_VERTICAL; background = shape(panel, 15); setPadding(dp(14), dp(8), dp(14), dp(8)); addView(label(value, 22, Color.WHITE, true)); addView(label(caption, 9, muted, true)) }
    private fun label(s: String, size: Int, color: Int, bold: Boolean = false) = TextView(this).apply { text = s; textSize = size.toFloat(); setTextColor(color); if (bold) typeface = Typeface.DEFAULT_BOLD }
    private fun row(block: LinearLayout.() -> Unit) = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; block() }
    private fun space(h: Int) = View(this).apply { layoutParams = LinearLayout.LayoutParams(1, dp(h)) }
    private fun spaceH(w: Int) = View(this).apply { layoutParams = LinearLayout.LayoutParams(dp(w), 1) }
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun shape(color: Int, radius: Int) = GradientDrawable().apply { setColor(color); cornerRadius = dp(radius).toFloat() }
}
