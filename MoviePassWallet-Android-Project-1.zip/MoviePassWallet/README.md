# MoviePass Wallet (Android)

A native Kotlin Android starter app for keeping cinema tickets together. Supports Android Sharesheet imports from PVR, BookMyShow, District and INOX, local ticket storage, ticket history filters and a ticket detail view.

## Current functionality
- Accepts shared text, PDF and image attachments via Android Sharesheet.
- Copies attachments into app-private storage and records ticket entries locally.
- Extracts basic fields from shared text (platform, movie title, date, time, seats, booking reference) using heuristic patterns.
- Manual file picker for PDF/images/text.
- Upcoming / Used / All filters and mark-as-used action.
- No account or server required for local ticket storage.

## Important limitations
- Shared PDF/image files are stored, but this starter does not perform OCR or extract embedded PDF text/QR codes. Such tickets are marked for review.
- A displayed booking reference is not a generated QR code. Actual admission QR/barcode rendering needs the original ticket's QR image or a proper decoder/renderer.
- Gmail live inbox sync is not enabled. It requires a Google Cloud project, Gmail API enablement, OAuth consent configuration, and a secure token flow. The app currently explains the required setup and supports sharing ticket content from Gmail into the app.
- Automatic background access to PVR/BookMyShow/District/INOX accounts is not implemented; these platforms do not expose one universal public ticket-import API. Share/import is the reliable cross-platform path.

## Build
Open this folder in Android Studio (Hedgehog or newer), allow Gradle sync, install Android SDK Platform 35, then Build > Build Bundle(s) / APK(s) > Build APK(s).

Command line (with Android SDK and Gradle 8.7 installed):
`gradle assembleDebug`

APK output: `app/build/outputs/apk/debug/app-debug.apk`
